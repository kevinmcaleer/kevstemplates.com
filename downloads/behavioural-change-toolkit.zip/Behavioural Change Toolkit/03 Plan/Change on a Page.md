---
title: Change on a Page
type: template
tags: [change/template, plan]
---

# Change on a Page

The artefact you will use most. One side of A4. If it doesn't fit, you haven't decided enough.

Copy everything below the line into a new note per initiative.

---

# `[Initiative name]` — Change on a Page

**Version:** `v0.1` **Date:** `___` **Owner:** `___` **Sponsor:** `___`

## Why

> In one sentence a frontline person would repeat accurately:
> `_______________________________________________`

**What happens if we don't:** `_______________`

## What changes

| | Today | From `[date]` |
|---|---|---|
| System | | |
| Process | | |
| Who decides | | |
| What gets measured | | |

**What is NOT changing:** `_______________`
*(People overestimate scope. This line is free reassurance.)*

## The vital few behaviours

| # | Who | Does what, when | Instead of | Primary barrier |
|---|---|---|---|---|
| B1 | | | | |
| B2 | | | | |
| B3 | | | | |

## What we're doing about each barrier

| Behaviour | Barrier (COM-B) | Intervention | Owner | By |
|---|---|---|---|---|
| B1 | | | | |
| B2 | | | | |
| B3 | | | | |

## What people stop doing

| Stops | Owner of stopping it | Date |
|---|---|---|
| | | |

⚠️ **If this table is empty, the plan is not finished.** Nothing gets added to a full day without something coming off.

## Who does what

| Role | Name | Their three commitments |
|---|---|---|
| Sponsor | | 1. 2. 3. |
| Change lead | | |
| Line managers | | |
| Champions | | |

## How we'll know

| | Metric | Baseline | Target | When | Source |
|---|---|---|---|---|---|
| Leading | | | | | |
| Leading | | | | | |
| Lagging | | | | | |
| Health | | | | | |

## Sequence

| Wave | Who | Date | Gate to proceed |
|---|---|---|---|
| Pilot | | | |
| 1 | | | |
| 2 | | | |

## Top three risks

| Risk | Mitigation | Owner |
|---|---|---|
| | | |
| | | |
| | | |

## Decisions needed from leadership

| Decision | By when | Who decides | Consequence of delay |
|---|---|---|---|
| | | | |

⭐ **This last table is the most important one on the page.** It converts your document from a status report into a request. Never take a change plan to a leadership meeting without it — a page with no ask gets noted and filed.

## Open questions

1. `___________`
2. `___________`

---

## Using it

- **Version it in the filename** and keep the old versions. When someone says "that's not what we agreed," you'll want the history.
- **Take it to every meeting.** Consistency of artefact is underrated — people learn to read it fast.
- **Change one thing after every review** and say what you changed and who prompted it. It proves consultation is real.
- **Circulate before, not during.** A page read in the meeting gets skimmed and argued with; a page read beforehand gets decided.

→ [[The One-Page Board Narrative]] for the exec version · [[Measurement Plan — Leading and Lagging]]
