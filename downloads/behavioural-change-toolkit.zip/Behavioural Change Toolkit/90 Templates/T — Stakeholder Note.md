---
title: T — Stakeholder Note
type: template
tags: [change/template]
---

# T — Stakeholder Note

One per stakeholder scoring 4+ on influence. Copy below the line.

---

```
---
type: stakeholder
tags: [stakeholder, change/INITIATIVE]
influence: 
interest: 
stance: neutral
owner: 
last-contact: 
---

# [Name] — [Role]

## Position
- **Influence (1–5):**
- **Interest (1–5):**
- **Stance:** Champion / Supporter / Neutral / Sceptic / Blocker
- **Quadrant:** Manage closely / Keep satisfied / Keep informed / Monitor

## What matters to them
- **What they want from this:**
- **What they're worried about:**
- **What they're protecting:**
- **What success looks like in their world:**
- **What they'd lose:**

## Influence network
- **Who they listen to:**
- **Who listens to them:**
- **Who they're aligned against:**

## History
- Were they involved in the decision? 
- Did they advocate a different solution?
- How did the last change land in their area?

## Approach
- **My objective with them:**
- **Next specific ask:**
- **What I'll offer:**
- **Route — direct or via [name]:**

## Contact log
| Date | What was discussed | Outcome | Next |
|---|---|---|---|
| | | | |
```

---

> [!warning] Write these as if they might be read
> Stakeholder notes have a way of being seen. Record positions and interests, not personal judgements. "Concerned about resourcing in their region" is useful and defensible. "Empire-building" is neither.

→ [[Stakeholder Map and Power Grid]]
