---
title: T — Intervention Note
type: template
tags: [change/template]
---

# T — Intervention Note

One per selected intervention. Copy below the line.

---

```
---
type: intervention
tags: [intervention, change/INITIATIVE]
behaviour: B1
function: 
owner: 
status: designed
start: 
apease-total: 
---

# [Intervention name]

## Links
- **Behaviour:** [[B1 — ]]
- **Barrier it removes:**
- **Intervention function:** Education / Persuasion / Incentivisation / Coercion / Training / Restriction / Environmental restructuring / Modelling / Enablement

## What we're doing
**What:**
**Who does it:**
**To whom:**
**Starts:**
**Duration:**
**Cost / effort:**

## APEASE
| Criterion | Score 1–5 | Note |
|---|---|---|
| Acceptability | | |
| Practicality | | |
| Effectiveness | | |
| Affordability | | |
| Side-effects | | |
| Equity | | |
| **Total** | | |

## Expected effect
- **We expect to see:**
- **By when:**
- **Measured by:**

## Kill criteria
We will stop or change this if:

**Decision date:**

## Side-effects
- What might get worse:
- Who might be disadvantaged:
- How it might be gamed:
- What we'll watch:

## Log
| Date | Note |
|---|---|
| | |
```

→ [[Intervention Design Worksheet]] · [[Nudge Library]]
