---
title: Toolkit Map (MOC)
type: moc
tags: [change/toolkit, moc]
---

# Toolkit Map

Full index of every note. See also [[Choose Your Tool]] and [[The 8-Week Sequence]].

## 01 Frameworks — the thinking
- [[COM-B and the Behaviour Change Wheel]] — the workhorse. Start here.
- [[EAST — Easy Attractive Social Timely]] — fast, practical intervention design
- [[ADKAR — Individual Change]] — diagnosing where a *person* is stuck
- [[Bridges Transition Model]] — the emotional side, and why endings matter
- [[Switch — Rider Elephant Path]] — the best framework for briefing a leader
- [[Diffusion of Innovations]] — who adopts when, and who to ignore
- [[Habit Loop and Behavioural Drift]] — why it slides back
- [[Social Norms and Influence]] — the most underused lever you have
- [[Myths and Traps in Change Management]] — read before you brief anyone

## 02 Diagnose — what's really happening
- [[Behavioural Diagnosis Canvas]] — the master one-pager
- [[Target Behaviour Definition]] — turn fog into observable actions
- [[Barrier Analysis — COM-B Interview Guide]] — questions that get real answers
- [[Stakeholder Map and Power Grid]] — influence, not org chart
- [[Change Readiness Assessment]] — scored, honest, uncomfortable
- [[Force Field Analysis]] — what's pushing, what's pushing back
- [[Resistance Decoder]] — resistance is data, not defiance

## 03 Plan — design the change
- [[Change on a Page]] — the artefact you'll use most
- [[Intervention Design Worksheet]] — barrier → intervention function → tactic
- [[Nudge Library]] — 40+ ready tactics, tagged by barrier type
- [[Pilot Design and Experiment Card]] — test before you scale
- [[Comms and Narrative Plan]] — messages, channels, sequence
- [[Champion Network Playbook]] — build the peer layer
- [[Measurement Plan — Leading and Lagging]] — prove it, or you're guessing

## 04 Deliver — make it happen
- [[Manager Conversation Guide]] — line managers are the whole ballgame
- [[Objection Handling Bank]] — the 15 things you will actually hear
- [[Workshop — Behavioural Diagnosis (90 min)]]
- [[Workshop — Design the Nudges (2 hr)]]
- [[Workshop — Leadership Alignment (half day)]]

## 05 Sustain — stop the slide
- [[Embedding and Reinforcement]]
- [[Drift Check — 30 60 90]]
- [[Change Retrospective]]

## 06 Advising Senior Leaders — your job
- [[Sponsor Briefing Pack]] — what you need from them, specifically
- [[Leader Behaviour Contract]] — their behaviours, written down
- [[Executive Failure Modes]] — the eight ways leaders sink their own change
- [[Challenging Upward — Scripts]] — saying the hard thing and surviving
- [[The One-Page Board Narrative]] — the paper that gets a decision

## 90 Templates
- [[T — Behaviour Note]]
- [[T — Stakeholder Note]]
- [[T — Intervention Note]]
- [[T — Experiment Note]]
- [[T — Weekly Change Log]]

## 99 Reference
- [[Glossary]]
- [[Sources and Further Reading]]

---

## Optional Dataview

If you have the Dataview plugin, uncomment these:

```
%%
TABLE barrier, owner, status FROM #behaviour SORT status ASC
%%
```

```
%%
TABLE influence, stance, owner FROM #stakeholder SORT influence DESC
%%
```
