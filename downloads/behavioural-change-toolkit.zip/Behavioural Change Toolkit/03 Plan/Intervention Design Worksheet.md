---
title: Intervention Design Worksheet
type: worksheet
tags: [change/worksheet, plan]
---

# Intervention Design Worksheet

Converts diagnosis into designed action. One per target behaviour.

**The rule this enforces: no intervention without a named barrier.** Anything that can't name the barrier it addresses gets cut. This single discipline removes most of the waste from a change plan.

---

## 1 · The behaviour

> [!note] Fill in
> **B-number:** `___`
> **Who:** `_______________`
> **Does what, when:** `_______________`
> **Instead of:** `_______________`
> **Current frequency:** `_______________`
> **Target frequency:** `_______________`

## 2 · The barrier — from evidence

From [[Barrier Analysis — COM-B Interview Guide]].

| COM-B component | Score 1–5 | Evidence |
|---|---|---|
| Physical Capability | `_` | |
| Psychological Capability | `_` | |
| Physical Opportunity | `_` | |
| Social Opportunity | `_` | |
| Reflective Motivation | `_` | |
| Automatic Motivation | `_` | |

**Primary barrier:** `_______________`
**Secondary barrier:** `_______________`

## 3 · Which intervention functions can work

Use the mapping from [[COM-B and the Behaviour Change Wheel]]:

```
Physical Capability      → Training, Enablement
Psychological Capability → Education, Training, Enablement
Physical Opportunity     → Restriction, Env. restructuring, Enablement
Social Opportunity       → Restriction, Env. restructuring, Modelling, Enablement
Reflective Motivation    → Education, Persuasion, Incentivisation, Coercion
Automatic Motivation     → Persuasion, Incentivisation, Coercion,
                           Env. restructuring, Modelling, Enablement
```

**Candidate functions for my primary barrier:** `_______________`

## 4 · Generate options

Take each candidate function and generate 2–3 concrete tactics. Raid [[Nudge Library]] and run the sprint in [[EAST — Easy Attractive Social Timely]].

| # | Function | Concrete tactic | Effort |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |

> [!tip] Force at least one "change the path" option
> Every list should contain at least one option that changes the environment rather than the person — a default, a removed field, a switched-off legacy route, an agenda change. These are usually the cheapest and most durable, and they're the ones a group of people brainstorming will systematically under-produce.

## 5 · APEASE filter

Score 1–5. See [[COM-B and the Behaviour Change Wheel]].

| # | Accept. | Practic. | Effect. | Afford. | Side-eff. | Equity | Total |
|---|---|---|---|---|---|---|---|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |
| 4 | | | | | | | |
| 5 | | | | | | | |
| 6 | | | | | | | |

**Selected:** `___________`
**Rejected, and why** *(write this down — you will be asked)*: `___________`

## 6 · The intervention spec

> [!note] Spec
> **What we will do:** `_______________`
> **Who does it:** `_______________`
> **To whom:** `_______________`
> **Starting:** `_______________`
> **How long:** `_______________`
> **Cost / effort:** `_______________`
> **What we expect to see, by when:** `_______________`
> **How we'll know it worked:** `_______________`
> **What we'll do if it doesn't:** `_______________`

That last line matters. Interventions that fail quietly consume budget indefinitely. Set a kill criterion now, while it's not personal.

## 7 · Side-effects check

- What might get worse? `___________`
- Who might this disadvantage — a shift, a site, part-time staff, a role? `___________`
- What might people do to game it? `___________`
- Does it conflict with an existing target or incentive? `___________`

⚠️ **The gaming question is not cynical, it's necessary.** If you measure a behaviour, people will optimise for the measure. Ask "what's the laziest way to score well on this without doing the real thing?" — and design that out before launch.

---

## The stack

Single interventions rarely shift a behaviour. Aim for a stack of three to four across different components:

| Layer | Example | Purpose |
|---|---|---|
| **Make it easy** | Cut form from 12 fields to 4 | Removes Physical Opportunity barrier |
| **Make it normal** | Weekly team-level adoption, positive framing | Social Opportunity |
| **Make it cued** | New behaviour attached to end-of-call | Automatic Motivation |
| **Make it rewarded** | System returns something useful within 24h | Reflective + Automatic Motivation |
| **Make it required** | Monday meeting runs off new system only | Restriction / Env. restructuring |

Log the result in [[T — Intervention Note]], then test it with [[Pilot Design and Experiment Card]].
