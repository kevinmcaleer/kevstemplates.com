---
title: Start Here
type: hub
tags: [change/toolkit, moc]
---

# 🧭 Behavioural Change Toolkit

A working vault for landing **behaviour change** in an organisation — built for someone whose job is to **advise senior leaders**, not to hold the plan.

It covers three overlapping changes at once:
- a **new system / tech rollout**
- a **new way of working / process**
- a **culture and behaviour shift**

These are not three programmes. They are one behaviour problem wearing three hats. The system fails if nobody uses it properly. The process fails if people route around it. The culture never shifts if the first two contradict it.

---

## The one idea this toolkit is built on

> **Stop asking "how do we get buy-in?" Start asking "who needs to do what differently, on Tuesday morning, and what's stopping them?"**

Buy-in is an attitude. Attitudes are slow, invisible and hard to move. **Behaviour** is observable, specific and changeable — and attitudes tend to follow behaviour rather than precede it. Every tool here forces the conversation down to the level of a named person doing a named thing.

---

## Start with your situation

| If you are… | Go to |
|---|---|
| Right at the beginning, nothing decided | [[Behavioural Diagnosis Canvas]] |
| Being asked "what's the plan?" by an exec on Friday | [[Change on a Page]] → [[The One-Page Board Narrative]] |
| Watching a sponsor drift or go quiet | [[Sponsor Briefing Pack]] → [[Executive Failure Modes]] |
| Hitting resistance you don't understand | [[Resistance Decoder]] → [[Barrier Analysis — COM-B Interview Guide]] |
| Told to "do some comms" as the solution | [[Myths and Traps in Change Management]] |
| Ready to design actual interventions | [[Intervention Design Worksheet]] → [[Nudge Library]] |
| Post-go-live and adoption is sliding | [[Drift Check — 30 60 90]] |
| Needing to tell a leader something they won't like | [[Challenging Upward — Scripts]] |

Full index: [[Toolkit Map (MOC)]] · Decision tree: [[Choose Your Tool]] · Timeline: [[The 8-Week Sequence]]

---

## How to use this vault

1. **Duplicate the folder per change initiative.** Or use the [[T — Behaviour Note]] template and tag notes with `#change/<initiative-name>` so several can live side by side.
2. **Fill in the worksheets in the note itself.** Every worksheet has `> [!note] Your answer` callouts — type straight into them. That's the point.
3. **The behaviour notes are the atoms.** One note per target behaviour, created from [[T — Behaviour Note]]. Everything else links back to them.
4. **Nothing here needs a plugin.** Dataview queries are included but commented out — uncomment if you have it installed.

---

## The five moves, in order

```
1. DIAGNOSE   →  What behaviour, by whom, and what's actually blocking it?
2. TARGET     →  Pick the vital few behaviours. Reject the rest out loud.
3. DESIGN     →  Match interventions to the real barrier, not the assumed one.
4. DELIVER    →  Run it small, learn, then scale. Managers do the heavy lifting.
5. SUSTAIN    →  Assume drift. Design for the moment attention leaves.
```

Most failed change skips 1 and 3 and does a great deal of 4.

---

## A warning worth reading before you brief anyone

The "**70% of change programmes fail**" statistic is almost certainly not true, and you should not repeat it. See [[Myths and Traps in Change Management]] — it has no reliable empirical basis, and quoting it in front of a sharp exec is a credibility risk. It also frames change as a coin-flip, which quietly excuses poor design.

---

## Folders

- `01 Frameworks` — the models, with a note on when each one is the wrong tool
- `02 Diagnose` — find out what's really going on
- `03 Plan` — design the intervention
- `04 Deliver` — run it, including workshop run-sheets
- `05 Sustain` — stop it sliding back
- `06 Advising Senior Leaders` — your actual job
- `90 Templates` — Obsidian templates
- `99 Reference` — glossary and sources
