---
title: Force Field Analysis
type: worksheet
tags: [change/worksheet, diagnose]
---

# Force Field Analysis

Kurt Lewin's tool, and still the fastest way to get a group to see the whole picture in twenty minutes.

**The core insight, and the reason it's worth doing:**

> **Removing a restraining force is usually cheaper and more effective than adding a driving force.**

Organisations instinctively add pressure — more comms, more targets, more escalation. Adding drivers to a system that is also restrained produces tension, stress and eventual snap-back. Removing the restraint lets the behaviour flow. This one idea reframes most stuck change programmes.

---

## The canvas

```
        DRIVING FORCES              │            RESTRAINING FORCES
     (pushing towards change)       │        (holding the current state)
                                    │
  ────────────────────────────►     │     ◄────────────────────────────
                                    │
  ──────────────────►               │            ◄──────────────────────
                                    │
  ────────────────────────►         │         ◄─────────────────────────
                                    │
                              CURRENT STATE
```

Arrow length = strength. Draw it on a whiteboard; the visual does work that a table doesn't.

---

## Worksheet

**Behaviour / change being analysed:** `_______________`

### Driving forces

| Force | Strength 1–5 | Can we strengthen it? How? |
|---|---|---|
| | | |
| | | |
| | | |
| | | |

### Restraining forces

| Force | Strength 1–5 | Can we remove or weaken it? How? | Cost |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

> [!note] Totals
> Driving total: `___` Restraining total: `___`
>
> If restraining ≥ driving, the change will not happen at current settings — regardless of how good the intent is.

---

## Common restraining forces in a tech + process + culture change

Prompt a group with these; they'll recognise several immediately.

- The new way takes longer at the point of use
- The old system still works and nobody turned it off ← **check this first**
- Reporting still requires the old format
- Middle managers weren't consulted and are quietly opting out
- Targets and incentives still reward the old behaviour
- Nobody has removed anything from anyone's day
- Two systems now hold the truth
- The people who were expert are now beginners, publicly
- IT access, licences or permissions are incomplete
- A previous similar initiative was abandoned and people are waiting it out
- The people affected can't see any benefit to themselves
- Senior leaders still ask for things the old way

> [!warning] "The old system still works"
> This deserves its own paragraph. Running the old route in parallel "just for a transition period" is the most common single cause of stalled tech adoption. It is always defended on risk grounds, and the transition period always extends. Get a hard switch-off date agreed *before* go-live, with a named owner — and if the answer is "we can't", that's important information about the real level of confidence in the new system.

---

## Turning it into action

Take your **three strongest restraining forces**. For each:

> [!note] Restraint removal
> **Restraint:** `_______________`
> **Who owns the thing causing it:** `_______________`
> **What would have to happen to remove it:** `_______________`
> **What it costs:** `_______________`
> **Who decides:** `_______________`
> **Asked by:** `_______________` (date)

**This list is your sponsor ask.** It's far more useful than "we need more visible support" because it's specific, decidable, and mostly within their gift. Removing organisational restraints is exactly what a sponsor is *for* — see [[Sponsor Briefing Pack]].

---

→ [[Resistance Decoder]] · [[Intervention Design Worksheet]] · [[Workshop — Behavioural Diagnosis (90 min)]]
