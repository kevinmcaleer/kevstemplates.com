---
title: Choose Your Tool
type: index
tags: [change/toolkit]
---

# Choose Your Tool

A decision tree for when you don't know where to start.

---

### "People aren't using the new system."

Do you know **why** yet — from talking to them, not from a survey?

- **No** → [[Barrier Analysis — COM-B Interview Guide]]. Six conversations will tell you more than a 400-response survey.
- **Yes, they can't** (skill, tools, access) → Capability/Opportunity problem → [[Intervention Design Worksheet]], look at Training and Enablement.
- **Yes, they won't** (don't see the point, prefer the old way) → Motivation problem → [[Social Norms and Influence]] + [[Resistance Decoder]].
- **Yes, they forget** → habit problem → [[Habit Loop and Behavioural Drift]] + [[Nudge Library]] (prompts and defaults).

⚠️ The single most common error: assuming "won't" when it's "can't". Managers reliably over-attribute to attitude. See [[Myths and Traps in Change Management]].

---

### "We need a change plan by Friday."

[[Change on a Page]] → fill it in → [[The One-Page Board Narrative]] for the exec version.

If you have 90 minutes with the right people first, run [[Workshop — Behavioural Diagnosis (90 min)]] and the plan writes itself.

---

### "The sponsor isn't showing up."

[[Sponsor Briefing Pack]] to make the ask concrete → [[Leader Behaviour Contract]] to make it visible → [[Challenging Upward — Scripts]] if it continues.

Active, visible sponsorship is repeatedly identified as the largest single contributor to change success. A quiet sponsor is not a minor risk — it is *the* risk.

---

### "Leadership say the right things but do the opposite."

[[Executive Failure Modes]] (specifically *Say–Do Gap*) → [[Leader Behaviour Contract]].

The organisation reads behaviour, not memos. One leader visibly bypassing the new process undoes six weeks of comms.

---

### "There's a lot of resistance."

[[Resistance Decoder]] first. Resistance is almost always one of: unclear ask, real cost you haven't acknowledged, loss of status/competence, prior broken promises, or a genuinely bad design. Only the last one is your fault, and only the last one is a compliment.

---

### "We rolled out. Adoption spiked then dropped."

Textbook drift. [[Habit Loop and Behavioural Drift]] → [[Drift Check — 30 60 90]] → [[Embedding and Reinforcement]].

The spike was novelty and supervision. The drop is the true baseline. Design for the drop.

---

### "How do we know if it's working?"

[[Measurement Plan — Leading and Lagging]]. If your only metric is "training completed" you are measuring attendance, not change.

---

### "We need to change the culture."

You can't change culture directly. You change **behaviours**; culture is the residue. Go to [[Target Behaviour Definition]] and force the aspiration ("more collaborative", "more accountable") into observable actions. If you can't film it, it isn't a behaviour.

---

### "Everyone's exhausted — there's too much change."

Real and legitimate. [[Change Readiness Assessment]] has a saturation section. The honest advice to a senior leader is often *sequence, or stop something*. Bring them the list of what's already running.
