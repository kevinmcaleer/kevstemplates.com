---
title: Diffusion of Innovations
type: framework
tags: [change/framework, sequencing]
use-when: Deciding who to roll out to first, and who to stop arguing with
---

# Diffusion of Innovations

Everett Rogers. Answers a question every rollout faces: **who first?**

---

## The five adopter groups

| Group | ~% | What they need | How to use them |
|---|---|---|---|
| **Innovators** | 2.5% | Novelty, early access | Useful for testing, **poor advocates** — peers see them as unrepresentative enthusiasts |
| **Early Adopters** | 13.5% | To be seen as ahead, and respected | 🎯 **Your target.** Opinion leaders. Everything hinges on them |
| **Early Majority** | 34% | Proof it works *here*, with people like them | Won't move until Early Adopters vouch |
| **Late Majority** | 34% | Norms, and the old option becoming inconvenient | Move when it's clearly the majority behaviour |
| **Laggards** | 16% | Necessity | Do not spend your energy here |

---

## The rule most rollouts break

> **Do not start with the loudest sceptic.**

There is a persistent instinct — often from a well-meaning exec — to "win over" the most vocal critic first, on the theory that if they convert, everyone follows. In practice you spend disproportionate effort, usually fail, and hand the sceptic a public platform during the fragile early phase.

**Start with the Early Adopters.** Build visible local proof. The sceptic is far more movable when 60% of their peers have already moved and the argument has been settled without them.

⚠️ One exception: if the sceptic is technically right about a design flaw, that's not resistance, that's free consultancy. See [[Resistance Decoder]].

---

## Identifying your Early Adopters

Not the org chart. Look for:

- People others ask before deciding — watch who gets copied into things
- Respected for competence, not just seniority
- Already frustrated with the current way (frustration is fuel)
- Socially connected across teams, not just within one
- Credible to the sceptics — a bit critical themselves

> [!tip] The two-question sociogram
> Ask 15 people: *"Who do you go to when you're not sure how to do something here?"* and *"Whose opinion on this change would you actually take seriously?"* Tally the names. The top 5–8 are your network, and they are frequently not who leadership expected. Bring that list to the sponsor — it's usually a genuinely surprising and useful piece of insight.

---

## What makes an innovation spread (Rogers' five attributes)

Design-test your change against these:

1. **Relative advantage** — is it visibly better *for the user*, not just the organisation?
2. **Compatibility** — does it fit existing values and ways of working?
3. **Complexity** — how hard is it to understand and use? (Lower is faster)
4. **Trialability** — can people try it without commitment or risk?
5. **Observability** — can others *see* the results?

Score your change 1–5 on each. Anything ≤2 is a spread blocker you can design around before launch — usually more cheaply than any comms campaign.

> [!note] Score your change
> Relative advantage: `___`
> Compatibility: `___`
> Complexity (5 = simple): `___`
> Trialability: `___`
> Observability: `___`
>
> Weakest attribute: `_______________`
> What we'll do about it: `_______________`

**Observability is the most commonly neglected.** If nobody can see who is doing the new thing and what they're getting from it, diffusion stalls regardless of how good it is.

---

## Sequencing a wave plan

| Wave | Who | Aim |
|---|---|---|
| 0 — Pilot | 1 team, high early-adopter density, sympathetic manager | Learn and fix. Expect to change the design. |
| 1 | Early adopters across sites | Generate local proof stories |
| 2 | Early majority, region by region | Momentum; publish adoption *trends* |
| 3 | Late majority | Norms + old route made inconvenient |
| 4 | Stragglers | Manager-led, individual, quiet |

Never announce a wave plan that implies Wave 4 people are laggards. Label waves by geography or function, never by attitude.

---

## Links

→ [[Champion Network Playbook]]
→ [[Social Norms and Influence]]
→ [[Pilot Design and Experiment Card]]
