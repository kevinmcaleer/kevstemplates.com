---
title: Behavioural Diagnosis Canvas
type: worksheet
tags: [change/worksheet, diagnose]
status: draft
---

# Behavioural Diagnosis Canvas

The master one-pager. Fill this in before anything else. If you can't complete it, you don't yet know enough to design a change — and that's a finding worth reporting.

⏱️ 60 minutes alone for a first draft, then 90 minutes with the core group.

---

## 1 · The change, in one sentence

> [!note] Fill in
> We are changing `_______________` so that `_______________`.
>
> **Deadline / go-live:** `___________`
> **Sponsor:** `___________`
> **My role:** `___________`

## 2 · What does success actually look like?

Not the milestone. What is observably different on an ordinary Tuesday?

> [!note] Fill in
> Six months from now, if this has worked, someone walking the floor would see:
> - `_______________`
> - `_______________`
> - `_______________`
>
> And they would **stop** seeing:
> - `_______________`

⚠️ If you can only describe success in terms of system usage or project milestones, go to [[Target Behaviour Definition]].

## 3 · Who has to do something differently?

| Group | Roughly how many | What they do **now** | What they must do **instead** | Priority |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

⚠️ Include leaders as a group. They almost always have to change too, and it's almost always left off this table.

## 4 · The vital few behaviours

Maximum five. Ruthlessly. Each must pass the **film test**: could you film someone doing it and know whether they did it?

| # | Behaviour | Who | When / trigger | Currently happening? |
|---|---|---|---|---|
| B1 | | | | ☐ Never ☐ Sometimes ☐ Often |
| B2 | | | | ☐ Never ☐ Sometimes ☐ Often |
| B3 | | | | ☐ Never ☐ Sometimes ☐ Often |
| B4 | | | | ☐ Never ☐ Sometimes ☐ Often |
| B5 | | | | ☐ Never ☐ Sometimes ☐ Often |

Create a note per behaviour from [[T — Behaviour Note]].

## 5 · COM-B barrier scan

For your top behaviour. Score each 1 (total blocker) to 5 (no issue). See [[COM-B and the Behaviour Change Wheel]].

| Component | Score | Evidence — how do I actually know? |
|---|---|---|
| Physical Capability | `_` | |
| Psychological Capability | `_` | |
| Physical Opportunity | `_` | |
| Social Opportunity | `_` | |
| Reflective Motivation | `_` | |
| Automatic Motivation | `_` | |

> [!warning] The evidence column is the point
> If your evidence is "we assume" or "the steering group thinks", you have an opinion, not a diagnosis. Go and have six conversations — [[Barrier Analysis — COM-B Interview Guide]].

**Lowest-scoring component = your primary barrier:** `_______________`

## 6 · Bright spots

Where is this behaviour *already* happening, even partially? Who, and what's different about their situation?

> [!note] Fill in
> `_______________`
>
> What can we copy? `_______________`

Bright spots are the cheapest source of solutions and the most credible evidence you'll ever put in front of a sceptic. See [[Switch — Rider Elephant Path]].

## 7 · What's genuinely in it for them?

> [!note] Fill in
> **For the organisation:** `_______________`
> **For the individual doing the behaviour:** `_______________`
> **What it costs them** (time, effort, status, autonomy, comfort): `_______________`

If the individual benefit column is empty or vague, that's your real problem, and no amount of comms will paper over it. Say so early.

## 8 · The honest risks

| Risk | Likelihood | Impact | What I'd do |
|---|---|---|---|
| Sponsor goes quiet | | | [[Sponsor Briefing Pack]] |
| Change saturation | | | [[Change Readiness Assessment]] |
| Middle managers don't cascade | | | [[Manager Conversation Guide]] |
| Design is genuinely worse for users | | | [[Resistance Decoder]] |
| | | | |

## 9 · What I don't know yet

> [!note] Fill in
> 1. `_______________`
> 2. `_______________`
> 3. `_______________`
>
> How I'll find out, by when: `_______________`

**Bring this section to your sponsor.** Naming your uncertainties builds far more credibility than a confident plan built on assumptions — and it protects you when one of them turns out to matter.

---

→ Next: [[Target Behaviour Definition]] · [[Stakeholder Map and Power Grid]] · [[Change on a Page]]
