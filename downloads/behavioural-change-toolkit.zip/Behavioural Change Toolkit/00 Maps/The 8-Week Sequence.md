---
title: The 8-Week Sequence
type: plan
tags: [change/toolkit]
---

# The 8-Week Sequence

A default running order. Compress or stretch it, but don't reorder it — the common failure is starting at Week 5.

---

## Weeks 1–2 · Diagnose

**Goal:** know what behaviour needs to change, for whom, and what the real barrier is.

- [ ] Draft [[Behavioural Diagnosis Canvas]] from what you already know (1 hr, alone)
- [ ] 6–10 conversations using [[Barrier Analysis — COM-B Interview Guide]] — frontline, not managers
- [ ] [[Stakeholder Map and Power Grid]]
- [ ] [[Change Readiness Assessment]] — score it honestly
- [ ] Run [[Workshop — Behavioural Diagnosis (90 min)]] with the core group

**Exit test:** you can name 3–5 specific behaviours and, for each, say whether the barrier is Capability, Opportunity or Motivation — with evidence, not opinion.

---

## Week 3 · Target and align

**Goal:** agree the vital few, and get the sponsor genuinely on the hook.

- [ ] [[Target Behaviour Definition]] — cut to a maximum of five
- [ ] [[Change on a Page]] v1
- [ ] [[Sponsor Briefing Pack]] — 45 minutes with the sponsor, one-to-one
- [ ] [[Leader Behaviour Contract]] drafted with the leadership team
- [ ] Run [[Workshop — Leadership Alignment (half day)]] if the top team is not aligned

**Exit test:** the sponsor can state the target behaviours from memory and has agreed to three specific things *they* will do.

⚠️ Do not proceed without this. Everything after Week 3 is wasted if the top of the house is not aligned.

---

## Weeks 4–5 · Design

**Goal:** interventions matched to actual barriers.

- [ ] [[Intervention Design Worksheet]] per target behaviour
- [ ] Raid the [[Nudge Library]]
- [ ] Score every option against APEASE — see [[COM-B and the Behaviour Change Wheel]]
- [ ] [[Comms and Narrative Plan]] — narrative *after* design, not before
- [ ] [[Measurement Plan — Leading and Lagging]] — baselines captured **now**
- [ ] [[Champion Network Playbook]] — recruit
- [ ] Run [[Workshop — Design the Nudges (2 hr)]]

**Exit test:** every intervention traces to a named barrier on a named behaviour. Anything that doesn't, gets cut.

---

## Week 6 · Pilot

**Goal:** find out you're wrong while it's cheap.

- [ ] [[Pilot Design and Experiment Card]] — one team, two weeks
- [ ] Brief managers with [[Manager Conversation Guide]]
- [ ] Collect leading indicators daily, not weekly

**Exit test:** you have changed at least one thing based on what the pilot told you. If nothing changed, you weren't listening.

---

## Weeks 7–8 · Deliver

- [ ] Scale to the next wave, sequenced by [[Diffusion of Innovations]] (early adopters first — never start with the sceptics)
- [ ] Managers cascade using [[Manager Conversation Guide]]
- [ ] Arm everyone with [[Objection Handling Bank]]
- [ ] Sponsor does something visible in week 7 — not a video

---

## From Week 9 · Sustain

This is where most programmes stop and most change dies.

- [ ] [[Drift Check — 30 60 90]] — put the three dates in the diary **today**
- [ ] [[Embedding and Reinforcement]] — get the behaviour into onboarding, objectives, and system defaults
- [ ] [[Change Retrospective]] at day 90
- [ ] Formally hand ownership to the line. Name the person.

---

## The three dates to book right now

| Date | What | Why |
|---|---|---|
| Week 3 | Sponsor one-to-one | The highest-leverage hour in the whole programme |
| Week 6 | Pilot review | Your last cheap chance to be wrong |
| Day 90 | Drift check | The behaviour has either stuck or quietly died by now |
